export interface CardProps {
    children: React.ReactNode;
    className?: string;
}
