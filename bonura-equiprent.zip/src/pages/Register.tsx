import RegisterForm from '../components/RegisterForm/RegisterForm';

const Register = () => {
    return (
        <div className="center-content">
            <RegisterForm />
        </div>
    );
}

export default Register;